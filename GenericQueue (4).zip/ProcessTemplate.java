import java.util.LinkedList;
import java.util.Random;

class ProcessTemplate<E> {


}

/*public class Generic<E> {
    //possibly abstract class
//attributes
    int ProcessID;
    int PriorityNumber;
    double ProcessArrivalTime;
    double ProcessServiceTime;
    private int queueSize;
    private E data;
    Node<E> head;
    Node<E> tail;
    Node<E> link;
//need to fix this error

    class GenericQ {
        public void engueue(E data, int PriorityID, int PriorityNumber) {
        if (tail == null) {
            head = new Node<E>(data,PriorityID);
            tail = head;
            return;
        }
        }
    }
}*/